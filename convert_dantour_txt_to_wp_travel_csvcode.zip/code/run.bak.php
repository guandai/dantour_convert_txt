<?php

$post_title = '';
function convert_text_to_data() {
    // Path to the data file
    $filePath = 'data.txt';

    // Check if the file exists
    if (!file_exists($filePath)) {
        die("File not found");
    }

    // Read the contents of the file
    $itineraryText = file_get_contents($filePath);

    // 提取 post_title （概述中的标题）
    preg_match('/##概述\n(.*)\n/', $itineraryText, $overviewMatches);
    if (isset($overviewMatches[1])) {
        $post_title = trim($overviewMatches[1]);
    } else {
        $post_title = 'Unknown Title';  // 如果没有匹配到概述，则给出默认值
    }

    // Split into sections based on "-----------------------------------"
    $days = preg_split('/-{3,}/', $itineraryText);
    $itineraries = [];

    foreach ($days as $day) {
        if (empty(trim($day))) continue;

        // Parse each section of the day
        preg_match_all('/##(.*?)\n(.*?)(?=(\n##|\z))/s', $day, $matches, PREG_SET_ORDER);
        $dayArray = [];
        $desc = '';

        foreach ($matches as $match) {
            $label = trim($match[1]);
            $content = trim($match[2]);

            switch ($label) {
                case '天数':
                    $dayArray['label'] = $content;
                    break;
                case '城市':
                    $dayArray['title'] = $content;
                    break;
                case '日期':
                    if ($content == '无') {
                        $dayArray['date'] = '';
                    } else {
                        $dayArray['date'] = $content;
                    }
                    break;
                case '早餐':
                    $desc .= "<p><strong>早餐</strong>: $content ";
                    break;
                case '午餐':
                    $desc .= "<strong>午餐</strong>: $content ";
                    break;
                case '晚餐':
                    $desc .= "<strong>晚餐</strong>: $content</p>";
                    break;
                default:
                    $desc .= "<strong>$label</strong>: $content</p><br/>";
            }
        }

        if (!empty($desc)) {
            $dayArray['desc'] = $desc;
        }

        $itineraries[] = $dayArray;
    }

    // Serialize the array of itineraries
    $serializedItineraries = serialize($itineraries);

    // 返回提取到的 post_title 和 serializedItineraries
    return ['post_title' => $post_title, 'serializedItineraries' => $serializedItineraries];
}


$extractedData = convert_text_to_data();
$post_title = $extractedData['post_title'];
$serializedData = $extractedData['serializedItineraries'];

$filePath = 'template.csv';  // Specify the path to your CSV file
$newFilePath = 'output.csv';  // Specify the path for the updated CSV

// Open the CSV file for reading
if (($handle = fopen($filePath, "r")) !== FALSE) {
    $newData = [];
    $header = fgetcsv($handle);  // Read the header row

    // Determine the index of 'wp_travel_trip_itinerary_data' column
    $itineraryDataIndex = array_search('wp_travel_trip_itinerary_data', $header);
    $postTitleIndex = array_search('wp_title', $header);

    // Read each line of the CSV file
    while (($data = fgetcsv($handle)) !== FALSE) {
        // Update the 'wp_travel_trip_itinerary_data' column with the serialized data
        $data[$itineraryDataIndex] = $serializedData;
        $data[$postTitleIndex] = $post_title;  // Update the post title column with extracted post_title
        $newData[] = $data;  // Append the modified data row to the new data array
    }
    fclose($handle);

    // Open a file for writing the updated data
    if (($handle = fopen($newFilePath, 'w')) !== FALSE) {
        // Write the header back to the new file
        fputcsv($handle, $header);
        
        // Write the new data rows back to the new file
        foreach ($newData as $row) {
            fputcsv($handle, $row);
        }
        fclose($handle);
        echo "CSV file has been updated successfully.";
    } else {
        echo "Error opening the file for writing.";
    }
} else {
    echo "Error opening the file for reading.";
}
